﻿Final Project.pdf
* * Part One-Section One Database Description Page 3
* ER-Model Page 4
* Relational Schema Page 5
* Functional Dependencies Page 7
* Normalization Page 8
* Indexes Page 9
* Views Page 10
* Three Sample Transactions Page 12


* Part One-Section Two User Manual Page 14
* Sample SQL Queries Page 15-20
* Table Descriptions Page 21-23
* INSERT & DELETE Syntax Page 24-25


* Part One-Section Three Graded Checkpoint Documents Page 26
* Checkpoint One Page 27
* Checkpoint Two Page 28-29
* Checkpoint Three Page 30-31
* Checkpoint Four Page 32-33
SampleQueries.txt
* The queries used to sample, analyze, and perform operations on the database
InsertDelete.txt
* Queries used to remove and add rows to the database
CreateTables.txt
* DDL dump from DataGrip to create tables if database is lost
Bookstore_Databse
* Database itself 
* When opened, refresh main for populated tables
Data_Files
* File folder containing all CSV files used for populating tables with data